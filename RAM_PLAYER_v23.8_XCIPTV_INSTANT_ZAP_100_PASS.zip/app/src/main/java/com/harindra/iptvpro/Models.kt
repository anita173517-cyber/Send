package com.harindra.iptvpro

import java.util.Locale

/**
 * RAM PLAYER v21.0 EXTREME MASTER EDITION — Core Data Models, Audio Diagnostics,
 * Playback Failure Classification, Device Optimization Profiles & Recycle Bin Records.
 */
enum class EntertainmentSection(val id: String, val displayTitle: String) {
    LIVE_TV("LIVE_TV", "LIVE TV"),
    MOVIES("MOVIES", "MOVIES"),
    SERIES("SERIES", "SERIES")
}

enum class ContentSourceType(val code: String) {
    M3U_LIVE("M3U_LIVE"),
    XTREAM_LIVE("XTREAM_LIVE"),
    XTREAM_VOD_MOVIE("XTREAM_VOD_MOVIE"),
    XTREAM_SERIES("XTREAM_SERIES"),
    XTREAM_SERIES_EPISODE("XTREAM_SERIES_EPISODE");

    fun isLiveTv(): Boolean = this == M3U_LIVE || this == XTREAM_LIVE
    fun isVodMovie(): Boolean = this == XTREAM_VOD_MOVIE
    fun isSeriesCatalogEntry(): Boolean = this == XTREAM_SERIES
    fun isSeriesEpisodeEntry(): Boolean = this == XTREAM_SERIES_EPISODE

    companion object {
        fun fromCode(raw: String?): ContentSourceType {
            if (raw.isNullOrBlank()) return M3U_LIVE
            return values().firstOrNull { it.code.equals(raw.trim(), ignoreCase = true) } ?: M3U_LIVE
        }
    }
}

enum class VodSortOrder(val id: String, val badgeLabel: String, val fullTitle: String) {
    RECENTLY_ADDED("RECENT", "RECENTLY ADDED", "Recently Added (Provider Order)"),
    NEW_TO_OLD("NEW_OLD", "NEW ↓ OLD", "Release / Added: Newest First"),
    OLD_TO_NEW("OLD_NEW", "OLD ↓ NEW", "Release / Added: Oldest First"),
    A_TO_Z("A_Z", "A ↓ Z", "Alphabetical: A to Z"),
    Z_TO_A("Z_A", "Z ↓ A", "Alphabetical: Z to A");

    fun nextOrder(): VodSortOrder {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }
}

enum class LiveChannelSortOrder(val id: String, val badgeLabel: String, val fullTitle: String) {
    CHANNEL_NUMBER("NUMBER", "CH #", "Channel Number (Default)"),
    A_TO_Z("A_Z", "A ↓ Z", "Alphabetical: A to Z"),
    Z_TO_A("Z_A", "Z ↓ A", "Alphabetical: Z to A"),
    CATEGORY("CATEGORY", "GROUP", "Grouped by Category"),
    RECENTLY_WATCHED("RECENT", "RECENT", "Recently Watched First");

    fun nextOrder(): LiveChannelSortOrder {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }

    companion object {
        fun fromId(id: String?): LiveChannelSortOrder {
            return values().firstOrNull { it.id == id } ?: CHANNEL_NUMBER
        }
    }
}

enum class UiDensityMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val tvPosterColumns: Int,
    val textScaleMultiplier: Float
) {
    COMPACT(
        id = "COMPACT",
        title = "Compact Density (6 Posters / Dense Rows)",
        subtitle = "Fits more posters and channels per screen on large 1080p/4K TVs",
        tvPosterColumns = 6,
        textScaleMultiplier = 0.94f
    ),
    STANDARD(
        id = "STANDARD",
        title = "Standard Density (5 Posters / Balanced)",
        subtitle = "Recommended default Android TV layout matching reference design",
        tvPosterColumns = 5,
        textScaleMultiplier = 1.0f
    ),
    CINEMATIC(
        id = "CINEMATIC",
        title = "Cinematic Comfortable (4 Large Posters / Larger Text)",
        subtitle = "Larger artwork cards and enhanced distance readability for living rooms",
        tvPosterColumns = 4,
        textScaleMultiplier = 1.10f
    );

    companion object {
        fun fromId(id: String?): UiDensityMode {
            return values().firstOrNull { it.id == id } ?: STANDARD
        }
    }
}

enum class PerformanceMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val focusDebounceMs: Long,
    val adjacentDelayMs: Long,
    val maxPreloadSegmentBytes: Int,
    val allowAdjacentSegmentPreload: Boolean,
    val reducedAnimations: Boolean,
    val recommendedBufferProfileId: String
) {
    AUTO_ADAPTIVE(
        id = "AUTO_ADAPTIVE",
        title = "Auto Adaptive Mode (Default Safe Optimization)",
        subtitle = "Automatically selects 512MB/1GB Safe, 2GB Balanced, or 4GB+ High Performance with heap guard",
        focusDebounceMs = 30L,
        adjacentDelayMs = 85L,
        maxPreloadSegmentBytes = 96 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "ULTRA_ZAP"
    ),
    SMART_BALANCED(
        id = "SMART_BALANCED",
        title = "Smart Balanced Mode (2GB Adaptive)",
        subtitle = "Adaptive prefetching + smooth 4D transitions for 2GB Android TVs",
        focusDebounceMs = 45L,
        adjacentDelayMs = 120L,
        maxPreloadSegmentBytes = 96 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "LOW_MEM"
    ),
    FAST_ZAPPING(
        id = "FAST_ZAPPING",
        title = "Ultra Fast Zapping Mode",
        subtitle = "Hyper-responsive 24ms focus warm-up & instant HLS edge handoff on broadband Wi-Fi",
        focusDebounceMs = 24L,
        adjacentDelayMs = 65L,
        maxPreloadSegmentBytes = 112 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "ULTRA_ZAP"
    ),
    LOW_MEMORY(
        id = "LOW_MEMORY",
        title = "Smart Low-Memory Mode (512MB / 1GB Safe)",
        subtitle = "Conservative poster loading, reduced animations & strict RAM bounds for 512MB/1GB TVs",
        focusDebounceMs = 85L,
        adjacentDelayMs = 240L,
        maxPreloadSegmentBytes = 48 * 1024,
        allowAdjacentSegmentPreload = false,
        reducedAnimations = true,
        recommendedBufferProfileId = "LOW_MEM"
    ),
    HIGH_PERFORMANCE_4GB(
        id = "HIGH_PERFORMANCE_4GB",
        title = "4GB+ High-Performance Mode (TV Box / 4GB+)",
        subtitle = "Expanded bounded playlist/EPG/poster caches & 20ms fast-zap prefetch with RAM safety guard",
        focusDebounceMs = 20L,
        adjacentDelayMs = 55L,
        maxPreloadSegmentBytes = 192 * 1024,
        allowAdjacentSegmentPreload = true,
        reducedAnimations = false,
        recommendedBufferProfileId = "ULTRA_ZAP"
    ),
    NETWORK_SAVER(
        id = "NETWORK_SAVER",
        title = "Network & Data Saver Mode",
        subtitle = "Manifest-only prefetch & bandwidth conservation for mobile hotspots / slow Wi-Fi",
        focusDebounceMs = 95L,
        adjacentDelayMs = 280L,
        maxPreloadSegmentBytes = 0,
        allowAdjacentSegmentPreload = false,
        reducedAnimations = false,
        recommendedBufferProfileId = "STABLE"
    );

    companion object {
        fun fromId(id: String?, isLowRamDevice: Boolean): PerformanceMode {
            return values().firstOrNull { it.id == id }
                ?: if (isLowRamDevice) AUTO_ADAPTIVE else AUTO_ADAPTIVE
        }
    }
}

/**
 * Genuine audio diagnostic status & failure classification (v21.0).
 * Never falsely reports audio as working when tracks are missing, unselected, or unsupported.
 */
enum class AudioFailureReason(val label: String) {
    NONE("Audio Active"),
    SOURCE_NO_AUDIO("Source Has No Audio Track"),
    UNSUPPORTED_CODEC("Audio Track Unsupported by Device Decoder"),
    DECODER_INIT_FAILED("Audio Decoder Initialization Failed"),
    OUTPUT_ROUTING_ERROR("Audio Output Device / Routing Error"),
    PROVIDER_STREAM_ERROR("Provider Stream Audio Error"),
    TRACK_UNSELECTED("Audio Track Exists But Not Selected")
}

data class AudioTrackDescriptor(
    val groupIndex: Int,
    val trackIndex: Int,
    val language: String,
    val label: String,
    val mimeType: String,
    val codecs: String,
    val channelCount: Int,
    val sampleRateHz: Int,
    val bitrateBps: Int,
    val isSupported: Boolean,
    val isSelected: Boolean
) {
    fun shortCodecName(): String {
        val m = mimeType.lowercase(Locale.ROOT)
        val c = codecs.lowercase(Locale.ROOT)
        return when {
            m.contains("eac3-joc") || c.contains("ec+3") -> "E-AC3 JOC (Atmos)"
            m.contains("eac3") || c.contains("ec-3") -> "E-AC3 (Dolby Digital+)"
            m.contains("ac3") || c.contains("ac-3") -> "AC3 (Dolby Digital)"
            m.contains("mp4a") && (c.contains("40.5") || c.contains("40.29")) -> "HE-AAC"
            m.contains("mp4a") || m.contains("aac") -> "AAC"
            m.contains("mpeg-l2") || m.contains("mp2") -> "MPEG Audio (MP2)"
            m.contains("mpeg") || m.contains("mp3") -> "MP3"
            m.contains("opus") -> "Opus"
            m.contains("vorbis") -> "Vorbis"
            m.contains("flac") -> "FLAC"
            m.contains("raw") || m.contains("pcm") -> "PCM"
            m.contains("vnd.dts") -> "DTS"
            m.contains("truehd") -> "TrueHD"
            mimeType.isNotBlank() -> mimeType.substringAfter('/').uppercase(Locale.ROOT)
            else -> "Unknown"
        }
    }

    fun channelLayoutLabel(): String = when (channelCount) {
        1 -> "Mono (1.0)"
        2 -> "Stereo (2.0)"
        6 -> "5.1 Surround"
        8 -> "7.1 Surround"
        in 3..16 -> "${channelCount}ch"
        else -> "Unknown"
    }
}

data class AudioDiagnosticsSnapshot(
    val audioDetected: Boolean,
    val totalTracks: Int,
    val supportedTracks: Int,
    val selectedTrack: AudioTrackDescriptor?,
    val allTracks: List<AudioTrackDescriptor>,
    val decoderStatus: String,
    val outputCapability: String,
    val recoveryStatus: String,
    val failureReason: AudioFailureReason
) {
    fun osdShortBadge(): String {
        val sel = selectedTrack
        return when {
            sel != null && failureReason == AudioFailureReason.NONE -> {
                val lang = sel.language.uppercase(Locale.ROOT).takeIf { it.isNotBlank() && it != "UND" } ?: "AUD"
                val ch = if (sel.channelCount > 0) "${sel.channelCount}ch" else ""
                val codec = sel.shortCodecName().substringBefore(' ')
                listOf(lang, codec, ch).filter { it.isNotBlank() }.joinToString(" ")
            }
            failureReason == AudioFailureReason.SOURCE_NO_AUDIO -> "NO AUDIO"
            failureReason == AudioFailureReason.UNSUPPORTED_CODEC -> "UNSUPPORTED AUD"
            failureReason == AudioFailureReason.DECODER_INIT_FAILED -> "AUD DEC ERR"
            failureReason == AudioFailureReason.OUTPUT_ROUTING_ERROR -> "AUD OUT ERR"
            failureReason == AudioFailureReason.TRACK_UNSELECTED -> "AUD RECOVERING"
            else -> "AUD PENDING"
        }
    }
}

/**
 * Granular playback failure categories for Universal Channel Playback Recovery (Part 5).
 */
enum class PlaybackFailureCategory(val displayLabel: String, val isRetryable: Boolean) {
    NONE("Healthy", false),
    LIVE_WINDOW_DRIFT("Live Window Drift", true),
    PROVIDER_AUTH_ERROR("Provider Auth / Expired (401/403)", false),
    HTTP_NOT_FOUND("Stream Not Found (404/410)", false),
    HTTP_RATE_LIMITED("Server Rate Limit (429)", true),
    HTTP_SERVER_ERROR("Server Overload (5xx)", true),
    HTTP_ERROR("HTTP Error", true),
    CONNECTION_TIMEOUT("Connection Timeout", true),
    DNS_ERROR("DNS Resolution Error", true),
    HLS_MANIFEST_ERROR("HLS Manifest Error", true),
    MISSING_SEGMENT("Missing Media Segment", true),
    UNSUPPORTED_CODEC("Unsupported Codec", false),
    DECODER_INIT_FAILED("Decoder Initialization Failed", true),
    NETWORK_ERROR("Network Connection Error", true),
    UNKNOWN("Playback Error", true)
}

/**
 * Ultra-lean Channel / Catalog model for 512MB–4GB+ Android Smart TVs (v21.0).
 */
data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val category: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val epgId: String = "",
    val backupUrl: String = "",
    val sourceType: ContentSourceType = ContentSourceType.M3U_LIVE,
    val categoryId: String = "",
    val containerExtension: String = "",
    val releaseDate: String = "",
    val rating: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val durationLabel: String = "",
    val trailerUrl: String = "",
    val addedTimestamp: Long = 0L,
    val seriesId: String = ""
) {
    fun displayNumberFormatted(): String = when {
        number < 10 -> "00$number"
        number < 100 -> "0$number"
        else -> number.toString()
    }

    /**
     * Stable deletion signature so individual channel deletion persists across app restarts,
     * playlist refreshes, and re-imports even if channel numbers shift.
     */
    fun deletionKey(): String {
        val urlHash = M3uParser.fnv1a64(streamUrl.substringBefore('?').trim()).toULong().toString(16)
        val normPair = M3uParser.fnv1a64NormalizedPair(category, name).toULong().toString(16)
        return "${sourceType.code}|$normPair|$urlHash"
    }

    fun isLiveTvChannel(): Boolean = sourceType.isLiveTv()
    fun isVodMovie(): Boolean = sourceType == ContentSourceType.XTREAM_VOD_MOVIE
    fun isSeriesEpisode(): Boolean =
        sourceType == ContentSourceType.XTREAM_SERIES || sourceType == ContentSourceType.XTREAM_SERIES_EPISODE
    fun isSeriesCatalogEntry(): Boolean = sourceType == ContentSourceType.XTREAM_SERIES

    fun primarySection(): EntertainmentSection = when (sourceType) {
        ContentSourceType.XTREAM_VOD_MOVIE -> EntertainmentSection.MOVIES
        ContentSourceType.XTREAM_SERIES, ContentSourceType.XTREAM_SERIES_EPISODE -> EntertainmentSection.SERIES
        ContentSourceType.M3U_LIVE, ContentSourceType.XTREAM_LIVE -> EntertainmentSection.LIVE_TV
    }

    fun extractReleaseYear(): String {
        if (releaseDate.length >= 4 && releaseDate.substring(0, 4).all { it.isDigit() }) {
            return releaseDate.substring(0, 4)
        }
        return MediaCatalogEngine.extractYearFromTitle(name)
    }

    fun extractQualityBadge(): String {
        return MediaCatalogEngine.extractQualityBadge(name, category, containerExtension.ifBlank { streamUrl })
    }

    fun cleanMovieDisplayTitle(): String = MediaCatalogEngine.cleanDisplayTitle(name)

    companion object {
        const val DEFAULT_PROGRAM = "Live Broadcast"
        const val DEFAULT_NEXT_PROGRAM = "Upcoming Show"
    }
}

data class XtreamCredentials(
    val profileName: String,
    val serverUrl: String,
    val username: String,
    val password: String,
    val preferredLiveExtension: String = "auto"
)

data class XtreamAccountInfo(
    val isAuthenticated: Boolean,
    val status: String,
    val isExpired: Boolean,
    val expDateEpochSec: Long,
    val activeConnections: Int,
    val maxConnections: Int,
    val allowedOutputFormats: List<String>,
    val preferredLiveFormat: String,
    val serverMessage: String = ""
)

data class EpgProgrammeDetail(
    val nowTitle: String,
    val nextTitle: String,
    val description: String = "",
    val timeWindow: String = "",
    val progressPercent: Int = 100
)

data class VodMovieDetailInfo(
    val streamId: String,
    val title: String,
    val posterUrl: String,
    val backdropUrl: String = "",
    val releaseDate: String = "",
    val rating: String = "",
    val genre: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val durationLabel: String = "",
    val containerExtension: String = "mp4",
    val trailerUrl: String = ""
) {
    fun hasGenuineTrailer(): Boolean {
        val trimmed = trailerUrl.trim()
        return trimmed.length >= 5
    }
}

data class PlaybackProgressEntry(
    val contentId: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtMs: Long,
    val contentType: ContentSourceType = ContentSourceType.XTREAM_VOD_MOVIE,
    val seriesKey: String = "",
    val seasonNumber: Int = 0,
    val episodeNumber: Int = 0
) {
    fun progressPercent(): Int {
        if (durationMs <= 0L) return 0
        return ((positionMs * 100L) / durationMs).toInt().coerceIn(1, 100)
    }

    fun isCompleted(): Boolean {
        if (durationMs <= 0L) return false
        return progressPercent() >= 95
    }

    fun isResumable(): Boolean {
        if (!contentType.isVodMovie() && !contentType.isSeriesEpisodeEntry() && !contentType.isSeriesCatalogEntry()) {
            return false
        }
        if (positionMs < 10_000L) return false
        if (durationMs <= 0L) return true
        return progressPercent() in 2..94
    }
}

data class SeriesEpisodeItem(
    val globalChannelIndex: Int,
    val channel: Channel,
    val seriesId: String,
    val seriesTitle: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val episodeTitle: String,
    val durationLabel: String = "",
    val plot: String = "",
    val releaseDate: String = ""
)

data class SeriesGroupSummary(
    val seriesKey: String,
    val seriesId: String,
    val title: String,
    val category: String,
    val categoryId: String = "",
    val posterUrl: String,
    val releaseDate: String = "",
    val releaseYear: String,
    val rating: String = "",
    val genre: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val qualityBadge: String,
    val addedTimestamp: Long = 0L,
    val representativeChannelIndex: Int,
    val seasons: Map<Int, List<SeriesEpisodeItem>>
) {
    val seasonCount: Int get() = seasons.size
    val totalEpisodes: Int get() = seasons.values.sumOf { it.size }
}

data class VodCategorySidebarItem(
    val categoryName: String,
    val count: Int,
    val isSpecialSection: Boolean = false
)

data class ZapBenchmarkMetrics(
    val keyPressToSelectionMs: Long,
    val selectionToPrepareMs: Long,
    val selectionToFirstFrameMs: Long,
    val channelSwitchCompletionMs: Long,
    val lastBufferingDurationMs: Long,
    val prefetchHitRatePercent: Int,
    val failedPrefetchRatePercent: Int
)

object MediaCatalogEngine {

    fun hasExplicitSeasonEpisodeToken(title: String): Boolean {
        val len = title.length
        if (len < 4) return false
        var i = 0
        while (i < len - 3) {
            val c = title[i]
            if ((c == 'S' || c == 's') && (i == 0 || !title[i - 1].isLetterOrDigit())) {
                var j = i + 1
                var sDigits = 0
                while (j < len && title[j].isDigit() && sDigits < 3) {
                    j++
                    sDigits++
                }
                if (sDigits in 1..2 && j < len) {
                    if (title[j] == ' ' || title[j] == '-' || title[j] == '.' || title[j] == '_') j++
                    if (j < len && (title[j] == 'E' || title[j] == 'e')) {
                        var k = j + 1
                        if (k < len && (title[k] == 'P' || title[k] == 'p')) k++
                        var eDigits = 0
                        while (k < len && title[k].isDigit() && eDigits < 4) {
                            k++
                            eDigits++
                        }
                        if (eDigits >= 1) return true
                    }
                }
            }
            i++
        }
        return false
    }

    fun extractYearFromTitle(title: String): String {
        val len = title.length
        if (len < 4) return ""
        var i = len - 4
        while (i >= 0) {
            val c0 = title[i]
            val c1 = title[i + 1]
            val c2 = title[i + 2]
            val c3 = title[i + 3]
            if (((c0 == '1' && c1 == '9') || (c0 == '2' && c1 == '0')) && c2.isDigit() && c3.isDigit()) {
                val year = (c0 - '0') * 1000 + (c1 - '0') * 100 + (c2 - '0') * 10 + (c3 - '0')
                val prevOk = i == 0 || !title[i - 1].isDigit()
                val nextOk = (i + 4 >= len) || !title[i + 4].isDigit()
                if (prevOk && nextOk && year in 1950..2035) {
                    return year.toString()
                }
            }
            i--
        }
        return ""
    }

    fun extractQualityBadge(title: String, category: String, extOrUrl: String): String {
        val combined = "$title $category".uppercase(Locale.ROOT)
        return when {
            combined.contains("4K") || combined.contains("UHD") || combined.contains("2160P") -> "4K UHD"
            combined.contains("1080P") || combined.contains("FHD") || combined.contains("FULL HD") -> "1080p"
            combined.contains("HEVC") || combined.contains("H265") || combined.contains("X265") -> "HEVC"
            combined.contains("720P") || combined.contains(" HD") || combined.endsWith("HD") -> "HD"
            combined.contains("WEB-DL") || combined.contains("WEBRIP") -> "WEB-DL"
            extOrUrl.equals("mkv", ignoreCase = true) || extOrUrl.endsWith(".mkv", ignoreCase = true) -> "MKV"
            extOrUrl.equals("mp4", ignoreCase = true) || extOrUrl.endsWith(".mp4", ignoreCase = true) -> "MP4"
            else -> ""
        }
    }

    fun cleanDisplayTitle(rawName: String): String {
        var cleaned = rawName.trim()
        if (cleaned.startsWith("🎬")) cleaned = cleaned.removePrefix("🎬").trim()
        if (cleaned.startsWith("📺")) cleaned = cleaned.removePrefix("📺").trim()
        return cleaned.ifBlank { rawName }
    }

    fun normalizeProviderCategory(rawCategory: String, section: EntertainmentSection, @Suppress("UNUSED_PARAMETER") itemName: String = ""): String {
        val stripped = rawCategory
            .removePrefix("🎬")
            .removePrefix("📺")
            .trim()
        if (stripped.isNotBlank()) {
            return stripped
        }
        return when (section) {
            EntertainmentSection.MOVIES -> "Uncategorized Movies"
            EntertainmentSection.SERIES -> "Uncategorized Series"
            EntertainmentSection.LIVE_TV -> "Live TV"
        }
    }

    fun buildXtreamSeriesGroups(seriesCatalog: List<Channel>): List<SeriesGroupSummary> {
        if (seriesCatalog.isEmpty()) return emptyList()
        val summaries = ArrayList<SeriesGroupSummary>(seriesCatalog.size)
        for (idx in seriesCatalog.indices) {
            val ch = seriesCatalog[idx]
            if (ch.sourceType != ContentSourceType.XTREAM_SERIES) continue
            val cleanTitle = cleanDisplayTitle(ch.name)
            val normCategory = normalizeProviderCategory(ch.category, EntertainmentSection.SERIES, cleanTitle)
            val resolvedSeriesId = ch.seriesId.ifBlank { ch.id.removePrefix("series_") }
            val resolvedKey = "xtream_series_$resolvedSeriesId"
            summaries.add(
                SeriesGroupSummary(
                    seriesKey = resolvedKey,
                    seriesId = resolvedSeriesId,
                    title = cleanTitle,
                    category = normCategory,
                    categoryId = ch.categoryId,
                    posterUrl = ch.logoUrl,
                    releaseDate = ch.releaseDate,
                    releaseYear = ch.extractReleaseYear(),
                    rating = ch.rating,
                    genre = normCategory,
                    plot = ch.plot.ifBlank { ch.epgId },
                    cast = ch.cast,
                    director = ch.director,
                    qualityBadge = ch.extractQualityBadge(),
                    addedTimestamp = ch.addedTimestamp,
                    representativeChannelIndex = idx,
                    seasons = emptyMap()
                )
            )
        }
        return summaries
    }

    fun findNextEpisodeInSeries(
        group: SeriesGroupSummary,
        currentSeason: Int,
        currentEpisodeNumber: Int,
        currentEpisodeId: String
    ): SeriesEpisodeItem? {
        val sortedSeasons = group.seasons.keys.sorted()
        val seasonEps = group.seasons[currentSeason].orEmpty().sortedBy { it.episodeNumber }
        val currentIdx = seasonEps.indexOfFirst {
            it.channel.id == currentEpisodeId || it.episodeNumber == currentEpisodeNumber
        }
        if (currentIdx >= 0 && currentIdx + 1 < seasonEps.size) {
            val candidate = seasonEps[currentIdx + 1]
            if (candidate.channel.id != currentEpisodeId) {
                return candidate
            }
        }
        val seasonPos = sortedSeasons.indexOf(currentSeason)
        if (seasonPos >= 0 && seasonPos + 1 < sortedSeasons.size) {
            val nextSeasonNum = sortedSeasons[seasonPos + 1]
            val nextSeasonEps = group.seasons[nextSeasonNum].orEmpty().sortedBy { it.episodeNumber }
            val firstOfNextSeason = nextSeasonEps.firstOrNull()
            if (firstOfNextSeason != null && firstOfNextSeason.channel.id != currentEpisodeId) {
                return firstOfNextSeason
            }
        }
        return null
    }

    fun findPreviousEpisodeInSeries(
        group: SeriesGroupSummary,
        currentSeason: Int,
        currentEpisodeNumber: Int,
        currentEpisodeId: String
    ): SeriesEpisodeItem? {
        val sortedSeasons = group.seasons.keys.sorted()
        val seasonEps = group.seasons[currentSeason].orEmpty().sortedBy { it.episodeNumber }
        val currentIdx = seasonEps.indexOfFirst {
            it.channel.id == currentEpisodeId || it.episodeNumber == currentEpisodeNumber
        }
        if (currentIdx > 0) {
            return seasonEps[currentIdx - 1]
        }
        val seasonPos = sortedSeasons.indexOf(currentSeason)
        if (seasonPos > 0) {
            val prevSeasonNum = sortedSeasons[seasonPos - 1]
            val prevSeasonEps = group.seasons[prevSeasonNum].orEmpty().sortedBy { it.episodeNumber }
            return prevSeasonEps.lastOrNull()
        }
        return null
    }
}

/**
 * Bounded runtime resource budgets for 512MB/1GB, 2GB, and 4GB+ Android TV devices (v21.0).
 * Enforces actual JVM heap safety bounds so 4GB+ mode can NEVER override available heap limits,
 * and falls back automatically to LOW_MEMORY whenever memory pressure occurs.
 */
data class DeviceOptimizationProfile(
    val mode: PerformanceMode,
    val label: String,
    val maxChannelCacheItems: Int,
    val maxPosterCacheMb: Int,
    val posterPrefetchConcurrency: Int,
    val prefetchQueueLimit: Int,
    val ramPreloadBudgetBytes: Int,
    val epgWindowHours: Int,
    val reducedGlassEffects: Boolean
) {
    companion object {
        fun resolve(
            selectedMode: PerformanceMode,
            totalRamMb: Long,
            isLowRamDevice: Boolean,
            underMemoryPressure: Boolean = false,
            maxJvmHeapMb: Long = 256L
        ): DeviceOptimizationProfile {
            val heapConstrained = maxJvmHeapMb in 1L..96L
            val effective = when {
                underMemoryPressure || heapConstrained -> PerformanceMode.LOW_MEMORY
                selectedMode == PerformanceMode.AUTO_ADAPTIVE && (isLowRamDevice || totalRamMb <= 1024L) -> PerformanceMode.LOW_MEMORY
                selectedMode == PerformanceMode.AUTO_ADAPTIVE && totalRamMb in 1025L..3071L -> PerformanceMode.SMART_BALANCED
                selectedMode == PerformanceMode.AUTO_ADAPTIVE && totalRamMb >= 3072L -> PerformanceMode.HIGH_PERFORMANCE_4GB
                selectedMode == PerformanceMode.HIGH_PERFORMANCE_4GB && (isLowRamDevice || totalRamMb <= 1024L) -> PerformanceMode.LOW_MEMORY
                else -> selectedMode
            }
            return when (effective) {
                PerformanceMode.HIGH_PERFORMANCE_4GB -> DeviceOptimizationProfile(
                    mode = PerformanceMode.HIGH_PERFORMANCE_4GB,
                    label = "4GB+ High-Performance Mode",
                    maxChannelCacheItems = 60_000,
                    maxPosterCacheMb = 48,
                    posterPrefetchConcurrency = 4,
                    prefetchQueueLimit = 3,
                    ramPreloadBudgetBytes = 320 * 1024,
                    epgWindowHours = 72,
                    reducedGlassEffects = false
                )
                PerformanceMode.LOW_MEMORY, PerformanceMode.NETWORK_SAVER -> DeviceOptimizationProfile(
                    mode = effective,
                    label = "512MB/1GB Low-RAM Safe Mode",
                    maxChannelCacheItems = 25_000,
                    maxPosterCacheMb = 12,
                    posterPrefetchConcurrency = 1,
                    prefetchQueueLimit = 1,
                    ramPreloadBudgetBytes = 128 * 1024,
                    epgWindowHours = 12,
                    reducedGlassEffects = true
                )
                else -> DeviceOptimizationProfile(
                    mode = effective,
                    label = if (effective == PerformanceMode.SMART_BALANCED) "2GB Balanced Adaptive Mode" else effective.title,
                    maxChannelCacheItems = 40_000,
                    maxPosterCacheMb = 24,
                    posterPrefetchConcurrency = 2,
                    prefetchQueueLimit = 2,
                    ramPreloadBudgetBytes = 256 * 1024,
                    epgWindowHours = 24,
                    reducedGlassEffects = false
                )
            }
        }
    }
}

/**
 * Genuine Recycle Bin soft-deleted entity record (v21.0).
 * Supports `"CHANNEL"`, `"CATEGORY"`, `"CUSTOM_GROUP"`, and `"PROFILE"`.
 * Separate from Hide/Unhide, Favorites, and Channel Blacklist.
 */
data class RecycleBinEntry(
    val id: String,
    val entityType: String, // "CHANNEL", "CATEGORY", "CUSTOM_GROUP", "PROFILE"
    val displayName: String,
    val payloadJson: String,
    val deletedAtEpochMs: Long,
    val accountScope: String = "default"
) {
    fun isExpired(nowMs: Long = System.currentTimeMillis(), retentionDays: Int = 30): Boolean {
        val maxAgeMs = retentionDays.coerceAtLeast(1) * 86_400_000L
        return (nowMs - deletedAtEpochMs) > maxAgeMs
    }
}
